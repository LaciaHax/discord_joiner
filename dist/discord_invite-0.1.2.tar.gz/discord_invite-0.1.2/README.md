discord joiner lib

usage
```
from discord_invite import joiner

token = 'YOUR_DISCORD_TOKEN'
invite = 'INVITE_CODE'
response = joiner(token, invite)
print(response)
```